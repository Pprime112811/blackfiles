# The Black Files

A fictional mystery investigation game designed for GitHub Pages.

## Publish on GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html`, `style.css`, and `script.js` to the repository root.
3. Open Settings → Pages.
4. Choose Deploy from a branch.
5. Select the main branch and `/root`.
6. Save and wait for GitHub to publish it.

The game is intentionally fictional and does not connect to the real dark web or access the player's computer.
